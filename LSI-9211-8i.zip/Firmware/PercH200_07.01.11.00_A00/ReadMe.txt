*******************************************************************************
** This release package contains the files necessary to flash the Dell
** H200A Adapter with:
**     Package version -------------- 7.01.11.00
**     Firmware Version ------------- 02.15.57.00
**     Option BIOS Version ---------- 7.01.04.00-Dellized_9
**     Boot services Driver Version - 2.00.01.06
**     NVDATA Version --------------- 0A.00.13.00
**


To flash, boot to a DOS environment and execute the included batch file from 
the Command line as:

     <path>:\flash.bat

     Where <path> is the path to the folder containing the contents of the release
     package.
