*******************************************************************************
** This release package contains the files necessary to flash the Dell
** H200A Adapter with:
**     Package version -------------- 07.01.33.00
**     Firmware Version ------------- 02.15.63.00
**     Option BIOS Version ---------- 7.01.09.00
**     Boot services Driver Version - 2.00.01.09
**     NVDATA Version --------------- 00.0A.00.15
**


To flash, boot to a DOS environment and execute the included batch file from 
the Command line as:

     <path>:\flash.bat

     Where <path> is the path to the folder containing the contents of the release
     package.
